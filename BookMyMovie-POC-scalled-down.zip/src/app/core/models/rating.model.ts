export interface Ratings {
    movieId: string;
    rating: string;
}
