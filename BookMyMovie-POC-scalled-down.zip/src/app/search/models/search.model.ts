export interface Movie {
    title: string;
    id: number;
  }
