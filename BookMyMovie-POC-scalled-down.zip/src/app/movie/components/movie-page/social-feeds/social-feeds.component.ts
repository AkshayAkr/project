import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-social-feeds',
  templateUrl: './social-feeds.component.html',
  styleUrls: ['./social-feeds.component.scss']
})
export class SocialFeedsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
